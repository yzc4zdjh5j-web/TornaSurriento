## Requested updates
- [x] Replace visible restaurant-name headings with the supplied logo and update the browser icon.
- [x] Add Instagram and TikTok links alongside Facebook.
- [x] Add an Italian/English selector and translate page, menu and booking form.
- [x] Verify language persistence, social destinations and mobile layout.