# Surriento Table By The Sea

Crea una landing page moderna, elegante e performante per la trattoria e pizzeria "Torna a Surriento", situata a Sorrento.

Design & Stile:

UI pulita, raffinata ma accogliente, responsive (mobile-first), con palette colori ispirata alla costiera (tonalità calde mediterranee, blu profondo, dettagli color limone e accenti in legno o pietra).

Hero section d'impatto con foto panoramica/del locale e CTA diretta: "Prenota un tavolo" / "Scopri il Menù".

Struttura & Sezioni:

Hero: Titolo "Torna a Surriento", sottotitolo "Trattoria e Pizzeria Tradizionale nel cuore di Sorrento", pulsanti d'azione rapidi.

Chi Siamo: Un racconto dell'atmosfera tipica sorrentina, dell'accoglienza familiare e della qualità dei prodotti locali.

Menù (Filtrabile):

Antipasti, fritti, primi, specialità, secondi, dolci, bibite

Info & Contatti:

Indirizzo: Via Santa Lucia, 1-3, 80067 Sorrento (NA)

Orari: Lun, Mer-Dom 12:00 - 15:00 e 19:00 - 23:00 (Martedì Chiuso)

Telefono: 081 878 2301

Social / Web:

Facebook: [facebook.com/tornaasurrientotrattoriapizzeria](https://facebook.com/tornaasurrientotrattoriapizzeria)

Footer: Mappa incorporata, link social, copyright e note legali.

Funzionalità:

Pulsante sticky o ben visibile per la chiamata rapida al numero fisso.

Form o modale interattivo per la prenotazione dei tavoli.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://surriento-table-by-the-sea.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/10253679-f3b4-4779-b907-c216ee345ec3).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
