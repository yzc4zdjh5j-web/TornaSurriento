import { createFileRoute } from "@tanstack/react-router";
import { createContext, useContext, useEffect, useState } from "react";
import { Phone, MapPin, Clock, Facebook, Instagram, CalendarDays, UtensilsCrossed } from "lucide-react";
import { toast } from "sonner";
import { useServerFn } from "@tanstack/react-start";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { MENU } from "@/lib/menu";
import { createBooking } from "@/lib/booking.functions";
import { T, CATEGORY_EN, NAME_EN, DESC_EN, type Lang } from "@/lib/i18n";
import logo from "@/assets/torna_a_surriento_logo.png.asset.json";
import interior from "@/assets/torna_a_surr_3.jpg.asset.json";
import gnocchi from "@/assets/torna_a_sorr.jpg.asset.json";
import entrance from "@/assets/torna_a_surr_2.jpg.asset.json";

const PHONE = "+390818782301";
const PHONE_LABEL = "081 878 2301";
const FB = "https://facebook.com/tornaasurrientotrattoriapizzeria";
const IG = "https://www.instagram.com/tornaasurrientotrattoria";
const TT = "https://www.tiktok.com/@tornaasurrientotrattoria";

const LangCtx = createContext<{ lang: Lang; setLang: (l: Lang) => void }>({ lang: "it", setLang: () => {} });
const useT = () => T[useContext(LangCtx).lang];

function TikTok({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M16.6 5.82A4.28 4.28 0 0 1 15.54 3h-3.09v12.4a2.59 2.59 0 0 1-2.59 2.5 2.6 2.6 0 0 1-2.59-2.6 2.6 2.6 0 0 1 3.37-2.48V9.66a5.69 5.69 0 0 0-6.46 5.64A5.7 5.7 0 0 0 9.88 21a5.69 5.69 0 0 0 5.66-5.7V9.01a7.35 7.35 0 0 0 4.3 1.38V7.3a4.3 4.3 0 0 1-3.24-1.48Z" />
    </svg>
  );
}

function Socials({ className = "" }: { className?: string }) {
  const links = [
    { href: FB, label: "Facebook", icon: <Facebook className="h-5 w-5" /> },
    { href: IG, label: "Instagram", icon: <Instagram className="h-5 w-5" /> },
    { href: TT, label: "TikTok", icon: <TikTok className="h-5 w-5" /> },
  ];
  return (
    <div className={`flex items-center gap-3 ${className}`}>
      {links.map((l) => (
        <a key={l.label} href={l.href} target="_blank" rel="noreferrer" aria-label={l.label}
          className="flex h-10 w-10 items-center justify-center rounded-full border border-current/30 transition hover:bg-accent hover:text-accent-foreground">
          {l.icon}
        </a>
      ))}
    </div>
  );
}

function LangSwitch() {
  const { lang, setLang } = useContext(LangCtx);
  return (
    <div className="flex shrink-0 overflow-hidden rounded-full border border-primary-foreground/40 text-xs font-bold">
      {(["it", "en"] as const).map((l) => (
        <Button key={l} variant="ghost" size="sm" onClick={() => setLang(l)} aria-pressed={lang === l} aria-label={l === "it" ? "Italiano" : "English"}
          className={`h-7 rounded-none px-3 text-xs uppercase transition ${lang === l ? "bg-primary-foreground text-primary" : "text-primary-foreground hover:bg-primary-foreground/15 hover:text-primary-foreground"}`}>
          {l}
        </Button>
      ))}
    </div>
  );
}

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Torna a Surriento — Trattoria e Pizzeria a Sorrento" },
      { name: "description", content: "Cucina sorrentina e napoletana in Via Santa Lucia, Sorrento. Scopri il menù e prenota un tavolo." },
      { property: "og:title", content: "Torna a Surriento — Trattoria e Pizzeria" },
      { property: "og:description", content: "Trattoria e Pizzeria tradizionale nel cuore di Sorrento. Prenota il tuo tavolo." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const [open, setOpen] = useState(false);
  const [lang, setLangState] = useState<Lang>("it");
  useEffect(() => {
    const saved = localStorage.getItem("lang");
    if (saved === "en" || saved === "it") setLangState(saved);
  }, []);
  useEffect(() => { document.documentElement.lang = lang; }, [lang]);
  const setLang = (l: Lang) => { setLangState(l); localStorage.setItem("lang", l); };
  return (
    <LangCtx.Provider value={{ lang, setLang }}>
    <div className="min-h-screen bg-background text-foreground">
      <Nav onBook={() => setOpen(true)} />
      <Hero onBook={() => setOpen(true)} />
      <About />
      <MenuSection />
      <Info onBook={() => setOpen(true)} />
      <Footer />
      <a
        href={`tel:${PHONE}`}
        aria-label={`${T[lang].call} ${PHONE_LABEL}`}
        className="fixed bottom-5 right-5 z-40 flex items-center gap-2 rounded-full bg-accent px-5 py-3 font-bold text-accent-foreground shadow-soft transition hover:scale-105"
      >
        <Phone className="h-5 w-5" />
        <span className="hidden sm:inline">{PHONE_LABEL}</span>
      </a>
      <BookingDialog open={open} onOpenChange={setOpen} />
    </div>
    </LangCtx.Provider>
  );
}

function Nav({ onBook }: { onBook: () => void }) {
  const t = useT();
  return (
    <header className="absolute inset-x-0 top-0 z-30">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-5 py-5">
        <a href="#" aria-label="Torna a Surriento" className="shrink-0">
          <img src={logo.url} alt="Torna a Surriento Trattoria" className="h-16 w-auto drop-shadow-lg sm:h-20" />
        </a>
        <nav className="hidden items-center gap-8 text-sm font-medium text-primary-foreground/90 md:flex">
          <a href="#chi-siamo" className="hover:text-accent">{t.about}</a>
          <a href="#menu" className="hover:text-accent">{t.menu}</a>
          <a href="#contatti" className="hover:text-accent">{t.contacts}</a>
        </nav>
        <div className="flex items-center gap-3">
          <LangSwitch />
          <Button onClick={onBook} size="sm" className="shrink-0 bg-accent text-accent-foreground hover:bg-accent/90">
            {t.book}
          </Button>
        </div>
      </div>
    </header>
  );
}

function Hero({ onBook }: { onBook: () => void }) {
  const t = useT();
  return (
    <section className="relative flex min-h-[92vh] items-end overflow-hidden">
      <img src={interior.url} alt="Sala interna di Torna a Surriento" className="absolute inset-0 h-full w-full object-cover" />
      <div className="absolute inset-0 bg-hero-overlay" />
      <div className="relative mx-auto w-full max-w-6xl px-5 pb-20 pt-32 text-primary-foreground">
        <p className="mb-4 text-xs font-bold uppercase tracking-[0.3em] text-accent">{t.tagline}</p>
        <h1 className="font-display font-semibold leading-tight drop-shadow-2xl max-w-3xl text-4xl sm:text-5xl md:text-6xl">
          {t.heroTitle}
        </h1>
        <p className="mt-6 max-w-xl text-lg text-primary-foreground/85 sm:text-xl">
          {t.heroSub}
        </p>
        <div className="mt-10 flex flex-wrap gap-3">
          <Button onClick={onBook} size="lg" className="h-12 bg-accent px-7 text-base text-accent-foreground hover:bg-accent/90">
            <CalendarDays className="h-5 w-5" /> {t.bookTable}
          </Button>
          <Button asChild size="lg" variant="outline" className="h-12 border-primary-foreground/60 bg-transparent px-7 text-base text-primary-foreground hover:bg-primary-foreground hover:text-primary">
            <a href="#menu"><UtensilsCrossed className="h-5 w-5" /> {t.discoverMenu}</a>
          </Button>
        </div>
      </div>
    </section>
  );
}

function About() {
  const t = useT();
  return (
    <section id="chi-siamo" className="mx-auto grid max-w-6xl gap-12 px-5 py-24 md:grid-cols-2 md:items-center">
      <div>
        <p className="text-xs font-bold uppercase tracking-[0.3em] text-terracotta">{t.about}</p>
        <h2 className="mt-3 text-4xl font-semibold text-primary sm:text-5xl">{t.aboutTitle}</h2>
        <div className="mt-6 space-y-4 text-lg leading-relaxed text-muted-foreground">
          <p>{t.about1}</p>
          <p>{t.about2}</p>
        </div>
      </div>
      <div className="relative">
        <img src={gnocchi.url} alt="Gnocchi alla sorrentina su piatto in ceramica" className="aspect-[4/5] w-full rounded-2xl object-cover shadow-soft" loading="lazy" />
        <img src={entrance.url} alt="L'ingresso della trattoria" className="absolute -bottom-8 -left-6 hidden w-1/2 rounded-xl border-4 border-background object-cover shadow-soft sm:block" loading="lazy" />
      </div>
    </section>
  );
}

function MenuSection() {
  const [active, setActive] = useState("all");
  const { lang } = useContext(LangCtx);
  const t = T[lang];
  const label = (c: { id: string; label: string }) => (lang === "en" ? CATEGORY_EN[c.id] ?? c.label : c.label);
  const desc = (d?: string) => (d && lang === "en" ? DESC_EN[d] ?? d : d);
  const cats = active === "all" ? MENU : MENU.filter((c) => c.id === active);
  return (
    <section id="menu" className="tile-pattern bg-secondary py-24">
      <div className="mx-auto max-w-6xl px-5">
        <div className="text-center">
          <p className="text-xs font-bold uppercase tracking-[0.3em] text-terracotta">{t.menuKicker}</p>
          <h2 className="mt-3 text-4xl font-semibold text-primary sm:text-5xl">{t.menuTitle}</h2>
        </div>
        <div className="mt-10 flex gap-2 overflow-x-auto pb-2 md:flex-wrap md:justify-center">
          {[{ id: "all", label: t.all }, ...MENU].map((c) => (
            <Button variant="outline"
              key={c.id}
              onClick={() => setActive(c.id)}
              className={`shrink-0 rounded-full border px-5 py-2 text-sm font-semibold transition ${
                active === c.id
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border bg-card text-foreground hover:border-primary"
              }`}
            >
              {c.id === "all" ? c.label : label(c)}
            </Button>
          ))}
        </div>
        <div className="mt-12 space-y-14">
          {cats.map((c) => (
            <div key={c.id}>
              <h3 className="mb-6 border-b border-wood/30 pb-3 text-3xl font-semibold text-wood">{label(c)}</h3>
              <ul className="grid gap-x-12 gap-y-6 md:grid-cols-2">
                {c.items.map((i) => (
                  <li key={i.name} className="min-w-0">
                    <div className="flex items-baseline gap-3">
                      <span className="min-w-0 font-display text-xl font-semibold text-primary">{lang === "en" ? NAME_EN[i.name] ?? i.name : i.name}</span>
                      <span className="flex-1 border-b border-dotted border-muted-foreground/40" />
                      <span className="shrink-0 font-bold text-terracotta">€ {i.price}</span>
                    </div>
                    {i.desc && <p className="mt-1 text-sm text-muted-foreground">{desc(i.desc)}</p>}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <p className="mt-12 text-center text-xs text-muted-foreground">{t.menuNote}</p>
      </div>
    </section>
  );
}

function Info({ onBook }: { onBook: () => void }) {
  const t = useT();
  return (
    <section id="contatti" className="bg-primary py-24 text-primary-foreground">
      <div className="mx-auto grid max-w-6xl gap-10 px-5 md:grid-cols-3">
        <div>
          <MapPin className="h-7 w-7 text-accent" />
          <h3 className="mt-4 text-2xl font-semibold">{t.where}</h3>
          <p className="mt-2 text-primary-foreground/80">Via Santa Lucia, 1-3<br />80067 Sorrento (NA)</p>
        </div>
        <div>
          <Clock className="h-7 w-7 text-accent" />
          <h3 className="mt-4 text-2xl font-semibold">{t.hours}</h3>
          <p className="mt-2 text-primary-foreground/80">
            {t.days}<br />12:00 – 15:00 · 19:00 – 23:00<br /><span className="text-accent">{t.closed}</span>
          </p>
        </div>
        <div>
          <Phone className="h-7 w-7 text-accent" />
          <h3 className="mt-4 text-2xl font-semibold">{t.contacts}</h3>
          <a href={`tel:${PHONE}`} className="mt-2 block text-xl font-bold hover:text-accent">{PHONE_LABEL}</a>
          <Socials className="mt-4" />
          <Button onClick={onBook} className="mt-6 bg-accent text-accent-foreground hover:bg-accent/90">{t.bookTable}</Button>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  const t = useT();
  return (
    <footer className="bg-foreground text-background">
      <iframe
        title="Mappa Torna a Surriento"
        src="https://www.google.com/maps?q=Via+Santa+Lucia+1,+80067+Sorrento+NA&output=embed"
        className="h-80 w-full border-0"
        loading="lazy"
      />
      <div className="mx-auto flex max-w-6xl flex-col gap-6 px-5 py-10 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex min-w-0 items-center gap-4">
          <img src={logo.url} alt="Torna a Surriento Trattoria" className="h-20 w-auto shrink-0" loading="lazy" />
          <div className="min-w-0">
            <p className="text-sm opacity-70">Via Santa Lucia, 1-3 · 80067 Sorrento (NA)</p>
          </div>
        </div>
        <Socials />
      </div>
      <div className="border-t border-background/10 px-5 py-5 text-center text-xs opacity-60">
        © {new Date().getFullYear()} Torna a Surriento · {t.rights} · Privacy & Cookie Policy
      </div>
    </footer>
  );
}

function BookingDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const submit = useServerFn(createBooking);
  const t = useT();
  const [loading, setLoading] = useState(false);
  const today = new Date().toISOString().slice(0, 10);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const date = String(f.get("date"));
    if (new Date(date + "T12:00:00").getDay() === 2) {
      toast.error(t.tuesday);
      return;
    }
    setLoading(true);
    try {
      await submit({
        data: {
          name: String(f.get("name")),
          phone: String(f.get("phone")),
          email: String(f.get("email") || ""),
          booking_date: date,
          booking_time: String(f.get("time")),
          guests: Number(f.get("guests")),
          notes: String(f.get("notes") || ""),
        },
      });
      toast.success(t.ok);
      onOpenChange(false);
    } catch {
      toast.error(t.err);
    } finally {
      setLoading(false);
    }
  }

  const times = ["12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30", "22:00"];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display text-3xl text-primary">{t.bookTable}</DialogTitle>
          <DialogDescription>{t.formDesc}</DialogDescription>
        </DialogHeader>
        <form onSubmit={onSubmit} className="grid gap-4">
          <div className="grid gap-2"><Label htmlFor="name">{t.name}</Label><Input id="name" name="name" required minLength={2} maxLength={100} /></div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="grid gap-2"><Label htmlFor="phone">{t.phone}</Label><Input id="phone" name="phone" type="tel" required minLength={6} maxLength={30} /></div>
            <div className="grid gap-2"><Label htmlFor="email">{t.email}</Label><Input id="email" name="email" type="email" maxLength={255} /></div>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div className="grid gap-2"><Label htmlFor="date">{t.date}</Label><Input id="date" name="date" type="date" min={today} required /></div>
            <div className="grid gap-2">
              <Label htmlFor="time">{t.time}</Label>
              <select id="time" name="time" required className="h-9 rounded-md border border-input bg-transparent px-2 text-sm">
                {times.map((t) => <option key={t}>{t}</option>)}
              </select>
            </div>
            <div className="grid gap-2"><Label htmlFor="guests">{t.guests}</Label><Input id="guests" name="guests" type="number" min={1} max={30} defaultValue={2} required /></div>
          </div>
          <div className="grid gap-2"><Label htmlFor="notes">{t.notes}</Label><Textarea id="notes" name="notes" maxLength={1000} placeholder={t.notesPh} /></div>
          <Button type="submit" disabled={loading} size="lg" className="mt-2">{loading ? t.sending : t.send}</Button>
          <p className="text-center text-xs text-muted-foreground">{t.preferCall} <a href={`tel:${PHONE}`} className="font-semibold text-primary">{PHONE_LABEL}</a></p>
        </form>
      </DialogContent>
    </Dialog>
  );
}
