<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# Stella guida

I clienti gustano un pasto tradizionale sorrentino ai tavoli della trattoria

## Metrica

Prenotazioni di tavoli inviate ogni settimana
